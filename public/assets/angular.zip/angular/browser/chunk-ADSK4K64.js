import{a as o}from"./chunk-EDFYBFRY.js";var s=class extends o{};export{s as a};
